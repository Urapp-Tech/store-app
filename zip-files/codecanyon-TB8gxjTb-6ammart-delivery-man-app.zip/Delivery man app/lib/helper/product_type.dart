enum RestaurantType {
  // ignore: constant_identifier_names
  ALL_RESTAURANT,
}