package com.sixamtech.sixam_mart_store_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
