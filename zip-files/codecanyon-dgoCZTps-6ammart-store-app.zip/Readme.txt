If you need only the changed files for mobile apps in V2.3.0 check the change files from V2.2.1 to V2.3.0 folder
otherwise please use "Store app" folder.

Documentation - https://docs.6amtech.com/